# Flappy Bird clone in Android Studio.

!["Flappy Bird clone in Android Studio."](https://github.com/rusahang/FlappyBird/blob/main/screenshot/screenshot.jpg "Flappy Bird clone in Android Studio.")

[![Flappy Bird clone in Android Studio](http://img.youtube.com/vi/SAhp9AwU_DA/0.jpg)](https://www.youtube.com/watch?v=SAhp9AwU_DA)

# Requirements
- **JDK 1.8 or Latest [Download](https://www.oracle.com/technetwork/java/javase/downloads/index.html)**
- **AndroidSDK [Download](https://developer.android.com/studio/index.html#resources)**
- **libGDX [Download](https://libgdx.com)**
